﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace WebApp.Models
{
    public class Carros : Conexao
    {

        public List<CarroModel> listCarros = new List<CarroModel>();

        public Carros()
        {
            listCarros = new List<CarroModel>();
            try
            {
                var con = OpenConnection();
                if (con != null)
                    TrueGet(con);
                else
                {
                    //Popula com dados em sessão caso a conexão não seja realizada com sucesso!
                    //FakeGet();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool CriaCarro(CarroModel CarroModelo)
        {
            listCarros = new List<CarroModel>();
            var con = OpenConnection();
            if (con != null)
            {
                TrueAdd(con, CarroModelo);
                return true;
            }
            else
                return false;
        }

        public bool AtualizaCarro(int id, CarroModel CarroModelo)
        {
            var con = OpenConnection();
            if (con != null)
            {
                TrueEdit(con, CarroModelo);
                return true;
            }
            else
                return false;
        }

        public CarroModel GetCarro(int id)
        {
            CarroModel _CarroModel = null;

            foreach (CarroModel _carro in listCarros)
                if (_carro.ID == id)
                    _CarroModel = _carro;



            return _CarroModel;

        }

        public bool DeletarCarro(int id)
        {
            var con = OpenConnection();
            if (con != null)
            {
                TrueDelete(con, id);
                return true;
            }
            else
                return false;
        }

        public void FakeGet()
        {
            int ID = 0;
            listCarros.Add(new CarroModel
            {
                ID = ID++,
                Modelo = "308",
                Marca = "Peugeot",
                Placa = "EXV1788",
                Ano = 2013,

            });
            listCarros.Add(new CarroModel
            {
                ID = ID++,
                Modelo = "March",
                Marca = "Nissan",
                Placa = "FFF1788",
                Ano = 2011,
            });
            listCarros.Add(new CarroModel
            {
                ID = ID++,
                Modelo = "Focus",
                Marca = "Fod",
                Placa = "KJX9188",
                Ano = 2015,
            });

        }

        public void TrueGet(SqlConnection con)
        {
            try
            {
                SqlCommand cmd = new SqlCommand();
                SqlDataReader reader;
                cmd.CommandText = " SELECT Carro.*, Usuario.Nome FROM Carro LEFT JOIN Usuario ON Carro.IDUsuario = Usuario.IDUsuario";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = con;
                reader = cmd.ExecuteReader();

                while (reader.Read())
                {

                    listCarros.Add(new CarroModel
                {
                    ID = (reader["IDCarro"] != DBNull.Value ? Convert.ToInt32(reader["IDCarro"]) : 0),
                    Marca = (reader["Marca"] != DBNull.Value ? reader["Marca"].ToString() : ""),
                    Modelo = (reader["Modelo"] != DBNull.Value ? reader["Modelo"].ToString() : ""),
                    Placa = (reader["Placa"] != DBNull.Value ? reader["Placa"].ToString() : ""),
                    Ano = (reader["Ano"] != DBNull.Value ? Convert.ToInt32(reader["Ano"]) : 0),
                    IDUsuario = (reader["IDUsuario"] != DBNull.Value ? Convert.ToInt32(reader["IDUsuario"]) : 0),
                    Dono = (reader["Nome"] != DBNull.Value ? reader["Nome"].ToString() : "")
                });

                }
                reader.Close();
                CloseConnection(con);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void FakeAdd(CarroModel CarroModelo)
        {
            if (listCarros != null && (listCarros.Count > 0))
            {
                var LastCar = listCarros.OrderByDescending(i => i.ID).FirstOrDefault();
                if (LastCar != null)
                    CarroModelo.ID = LastCar.ID + 1;
            }
            else
                CarroModelo.ID = 1;

            listCarros.Add(CarroModelo);
        }

        public void TrueAdd(SqlConnection con, CarroModel CarroModelo)
        {
            try
            {

                SqlCommand cmd = new SqlCommand();
                string query = @"
                                    INSERT INTO Carro
                                               (Marca
                                               ,Modelo
                                               ,Placa
                                               ,Ano
                                               ,IDUsuario)
                                         VALUES
                                               ('{0}',
                                                '{1}',
                                                '{2}',
                                                '{3}',
                                               '{4}')
                                                     ";

                cmd.CommandText = string.Format(query, CarroModelo.Marca, CarroModelo.Modelo, CarroModelo.Placa, CarroModelo.Ano, CarroModelo.IDUsuario);
                cmd.CommandType = CommandType.Text;
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                TrueGet(con);
                CloseConnection(con);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public void FakeDelete(int id)
        {
            foreach (CarroModel _carro in listCarros)
            {
                if (_carro.ID == id)
                {
                    listCarros.Remove(_carro);
                    break;
                }
            }
        }

        public void TrueDelete(SqlConnection con, int id)
        {
            try
            {
                listCarros = new List<CarroModel>();

                SqlCommand cmd = new SqlCommand();
                string query = @" DELETE Carro WHERE IDCarro = {0}";

                cmd.CommandText = string.Format(query, id);
                cmd.CommandType = CommandType.Text;
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                TrueGet(con);
                CloseConnection(con);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public void FakeEdit(int id)
        {

        }

        public void TrueEdit(SqlConnection con, CarroModel CarroModelo)
        {
            try
            {
                listCarros = new List<CarroModel>();
                SqlCommand cmd = new SqlCommand();
                string query = @" UPDATE Carro SET Marca = '{0}', Modelo = '{1}', Placa = '{2}', Ano = '{3}' WHERE IDCarro = '{4}'";

                cmd.CommandText = string.Format(query, CarroModelo.Marca, CarroModelo.Modelo, CarroModelo.Placa, CarroModelo.Ano, CarroModelo.ID);
                cmd.CommandType = CommandType.Text;
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                TrueGet(con);
                CloseConnection(con);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }


    }
}