﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace WebApp.Models
{
    public class UsuarioModel
    {   
        public int ID { get; set; }

        [DisplayName("Nome")]
        [StringLength(30, ErrorMessage = "O campo Nome permite no máximo 30 caracteres!")]
        [Required(ErrorMessage = "Informe o Nome")]
        public string Nome { get; set; }

        [DisplayName("Sobrenome")]
        [StringLength(50)]
        public string SobreNome { get; set; }

        [DisplayName("Endereço")]
        [StringLength(300, ErrorMessage = "O campo Endereço permite no máximo 300 caracteres!")]
        public string Endereco { get; set; }

        
        [DisplayName("E-mail")]
        [StringLength(100, ErrorMessage = "O campo E-mail permite no máximo 100 caracteres!")]
        [Required(ErrorMessage = "Informe o Email")]
        [RegularExpression(@"\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*", ErrorMessage = "Email inválido.")]
        public string Email { get; set; }


        [DisplayName("Data Nascimento")]
        [DataType(DataType.Date)]
        [Required(ErrorMessage = "Informe a Data de Nascimento")]
        public DateTime Nascimento { get; set; }


        [DisplayName("Tem Carros S/N?")]
        public string TemCarros { get; set; }

    }
}