﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace WebApp.Models
{
    public class Conexao
    {
        public SqlConnection OpenConnection()
        {
            SqlConnection con;
            try
            {

                con = new System.Data.SqlClient.SqlConnection();
                con.ConnectionString = @"Data Source=DESKTOP-9DTTPPU\SQLEXPRESS;Initial Catalog=WebApp;Integrated Security=True";
                con.Open();
                return con;
            }
            catch
            {
                return null;
            }
        }

        public void CloseConnection(SqlConnection con)
        {
            if (con != null && (con.State == ConnectionState.Open))
                con.Close();
        }
    }
}