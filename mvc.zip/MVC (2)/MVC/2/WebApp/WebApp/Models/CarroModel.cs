﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace WebApp.Models
{
    public class CarroModel
    {
        public int IDUsuario { get; set; }
        public int ID { get; set; }

        [DisplayName("Marca")]
        [StringLength(30, ErrorMessage = "O campo Marca permite no máximo 30 caracteres!")]
        [Required(ErrorMessage = "Informe a Marca")]
        public string Marca { get; set; }

        [DisplayName("Modelo")]
        [StringLength(30)]
        [Required(ErrorMessage = "Informe o Modelo")]
        public string Modelo { get; set; }

        [DisplayName("Placa")]
        [StringLength(30)]
        [Required(ErrorMessage = "Informe a Placa")]
        public string Placa { get; set; }


        [DisplayName("Ano")]
        public int Ano { get; set; }


        [DisplayName("Dono")]
        public string Dono { get; set; }
    }
}