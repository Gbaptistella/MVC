﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace WebApp.Models
{
    public class Usuarios : Conexao
    {
        public List<UsuarioModel> listUsuarios = new List<UsuarioModel>();

        public Usuarios()
        {
            listUsuarios = new List<UsuarioModel>();

            var con = OpenConnection();
            if (con != null)
                TrueGet(con);
            else
            {

            }
        }



        public bool CriaUsuario(UsuarioModel usuarioModelo)
        {
            listUsuarios = new List<UsuarioModel>();
            var con = OpenConnection();
            if (con != null)
            {
                TrueAdd(con, usuarioModelo);
                return true;
            }
            else
                return false;
        }

        public bool AtualizaUsuario(int id, UsuarioModel usuarioModelo)
        {
            var con = OpenConnection();
            if (con != null)
            {
                TrueEdit(con, usuarioModelo);
                return true;
            }
            else
                return false;

        }

        public UsuarioModel GetUsuario(int id)
        {
            UsuarioModel _usuarioModel = null;

            foreach (UsuarioModel _usuario in listUsuarios)
                if (_usuario.ID == id)
                    _usuarioModel = _usuario;

            return _usuarioModel;

        }

        public bool DeletarUsuario(int id)
        {
            var con = OpenConnection();
            if (con != null)
            {
                TrueDelete(con, id);
                return true;
            }
            else
                return false;
        }

        public void FakeGet()
        {
            int ID = 0;
            listUsuarios.Add(new UsuarioModel
            {
                ID = ID++,
                Nome = "Pedro",
                SobreNome = "Souza",
                Endereco = "Rua Souza , 150",
                Email = "PSouza@teste.com",
                Nascimento = Convert.ToDateTime("05/09/1980")
            });
            listUsuarios.Add(new UsuarioModel
            {
                ID = ID++,
                Nome = "Cris",
                SobreNome = "Pereira",
                Endereco = "Rua Pereira , 129 - Ap 81",
                Email = "CPereira@teste.com",
                Nascimento = Convert.ToDateTime("01/05/1975")
            });
            listUsuarios.Add(new UsuarioModel
            {
                ID = ID++,
                Nome = "Gustavo",
                SobreNome = "Baptistella",
                Endereco = "Rua Baptistella , 190 - AP 81",
                Email = "gbaptistellasolutions@gmail.com",
                Nascimento = Convert.ToDateTime("16/10/1989")
            });

        }

        public void TrueGet(SqlConnection con)
        {
            try
            {

                SqlCommand cmd = new SqlCommand();
                SqlDataReader reader;
                cmd.CommandText = @"SELECT USUARIO.*, Carro.IDCarro FROM USUARIO LEFT JOIN CARRO ON USUARIO.IDUsuario =CARRO.IDUsuario";



                cmd.CommandType = CommandType.Text;
                cmd.Connection = con;
                reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    string Data = "";

                    if (reader["DataNascimento"] != DBNull.Value)
                        Data = reader["DataNascimento"].ToString().Substring(0, 10);


                    if (listUsuarios != null && (listUsuarios.Count > 0))
                    {
                        var exists = listUsuarios.Where(i => i.ID == Convert.ToInt32(reader["IDUsuario"])).FirstOrDefault();
                        if (exists != null)
                            continue;
                    }

                    listUsuarios.Add(new UsuarioModel
                {
                    ID = (reader["IDUsuario"] != DBNull.Value ? Convert.ToInt32(reader["IDUsuario"]) : 0),
                    Nome = (reader["Nome"] != DBNull.Value ? reader["Nome"].ToString() : ""),
                    SobreNome = (reader["SobreNome"] != DBNull.Value ? reader["SobreNome"].ToString() : ""),
                    Endereco = (reader["Endereco"] != DBNull.Value ? reader["Endereco"].ToString() : ""),
                    Email = (reader["Email"] != DBNull.Value ? reader["Email"].ToString() : ""),
                    Nascimento = Convert.ToDateTime(Data),
                    TemCarros = (reader["IDCarro"] != DBNull.Value ? "S" : "N")
                });

                }
                reader.Close();
                CloseConnection(con);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void FakeAdd(UsuarioModel usuarioModelo)
        {
            FakeGet();
            if (listUsuarios != null && (listUsuarios.Count > 0))
            {
                var LastUser = listUsuarios.OrderByDescending(i => i.ID).FirstOrDefault();
                if (LastUser != null)
                    usuarioModelo.ID = LastUser.ID + 1;
            }
            else
                usuarioModelo.ID = 1;

            listUsuarios.Add(usuarioModelo);
        }

        public void TrueAdd(SqlConnection con, UsuarioModel usuarioModelo)
        {
            try
            {

                SqlCommand cmd = new SqlCommand();
                string query = @"
                                    INSERT INTO Usuario
                                               (Nome
                                               ,Sobrenome
                                               ,Endereco
                                               ,Email
                                               ,DataNascimento)
                                         VALUES
                                               ('{0}',
                                                '{1}',
                                                '{2}',
                                                '{3}',
                                               '{4}')
                                                     ";

                cmd.CommandText = string.Format(query, usuarioModelo.Nome, usuarioModelo.SobreNome, usuarioModelo.Endereco, usuarioModelo.Email, usuarioModelo.Nascimento.ToString("MM/dd/yyyy"));
                cmd.CommandType = CommandType.Text;
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                TrueGet(con);
                CloseConnection(con);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public void FakeDelete(int id)
        {
            foreach (UsuarioModel _usuario in listUsuarios)
            {
                if (_usuario.ID == id)
                {
                    listUsuarios.Remove(_usuario);
                    break;
                }
            }
        }

        public void TrueDelete(SqlConnection con, int id)
        {
            try
            {
                listUsuarios = new List<UsuarioModel>();

                SqlCommand cmd = new SqlCommand();
                string query = @" DELETE Usuario WHERE IDUsuario = {0}";

                cmd.CommandText = string.Format(query, id);
                cmd.CommandType = CommandType.Text;
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                TrueGet(con);
                CloseConnection(con);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public void FakeEdit(int id)
        {

        }

        public void TrueEdit(SqlConnection con, UsuarioModel usuarioModelo)
        {
            try
            {
                listUsuarios = new List<UsuarioModel>();
                SqlCommand cmd = new SqlCommand();
                string query = @" UPDATE Usuario SET Nome = '{0}', Sobrenome = '{1}', Endereco = '{2}', Email = '{3}' WHERE IDUsuario = '{4}'";

                cmd.CommandText = string.Format(query, usuarioModelo.Nome, usuarioModelo.SobreNome, usuarioModelo.Endereco, usuarioModelo.Email, usuarioModelo.ID);
                cmd.CommandType = CommandType.Text;
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                TrueGet(con);
                CloseConnection(con);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
    }
}