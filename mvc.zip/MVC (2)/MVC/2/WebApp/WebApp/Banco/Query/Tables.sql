DROP TABLE Carro;
DROP TABLE Usuario;

CREATE TABLE Usuario (
    IDUsuario int IDENTITY(1,1) PRIMARY KEY,
    Nome varchar(30) NOT NULL,
    Sobrenome varchar(50),
	Endereco varchar(300),
	Email varchar(100) NOT NULL,
	DataNascimento Datetime
);


CREATE TABLE Carro (
    IDCarro int IDENTITY(1,1) PRIMARY KEY,
    Marca varchar(30) NOT NULL,
	Modelo varchar(30) NOT NULL,
	Placa varchar(30) NOT NULL,
	Ano   int,
    IDUsuario int FOREIGN KEY REFERENCES Usuario(IDUsuario)
);
