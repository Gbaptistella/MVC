Para rodar o programa com sucesso, favor verificar os pr� requisitos.

1- Ter SQLServer2005 ou Superior Instalado na m�quina 
2- Ter VisualStudio 2013 ou Superior Instalado na m�quina
3- Executar os scripts da pasta Banco/Query na seguinte ordem: Banco.sql, Tables.sql (Necess�rio Ser ADMIN do Banco de Dados)
4- Iniciar o programa, em caso de erro verificar a string de conex�o que voc� criou no passo 3
5- Alterar string de conex�o na classe: WebApp\WebApp\Models\Conexao.cs, passando a sua string criada no passo 3. Linha 19:

con.ConnectionString = @"Data Source=DESKTOP-9DTTPPU\SQLEXPRESS;Initial Catalog=WebApp;Integrated Security=True";

6- Iniciar o Programa novamente!