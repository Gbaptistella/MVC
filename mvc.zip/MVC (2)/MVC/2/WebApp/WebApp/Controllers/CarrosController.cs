﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApp.Models;

namespace WebApp.Controllers
{
    public class CarrosController : Controller
    {
        private static Carros _carros = new Carros();
        public ActionResult Index()
        {
            Session["Visible"] = "N";

            return View(_carros.listCarros);
        }

        public ActionResult GetCarros(int ID)
        {
            _carros.GetCarro(ID);

            _carros.listCarros.RemoveAll(i => i.IDUsuario != ID);

            if (_carros.listCarros != null && (_carros.listCarros.Count > 0))
                Session["IDUsuario"] = _carros.listCarros.FirstOrDefault().IDUsuario;
            else
                Session["IDUsuario"] = ID;

            _carros = new Carros();
            Session["Visible"] = "S";
            return View("Index", _carros.listCarros.Where(i => i.IDUsuario == ID));
        }

        public ActionResult AdicionaCarro()
        {
            var ID = Session["IDUsuario"];
            return View();
        }

        [HttpPost]
        public ActionResult AdicionaCarro(CarroModel _carroModel)
        {
            var ID = Session["IDUsuario"];
            if (ID != null)
                _carroModel.IDUsuario = Convert.ToInt32(ID);

            if (!_carros.CriaCarro(_carroModel))
                Session["Message"] = "Erro ao abrir conexão! Verificar arquivo ReadMe.txt";
            else
                Session["Message"] = "";

            return RedirectToAction("Index");
        }

        public ViewResult DeletaCarro(int id)
        {
            _carros.listCarros.Where(i => i.ID == id);
            return View(_carros.GetCarro(id));
        }

        [HttpPost]
        public RedirectToRouteResult DeletaCarro(int id, FormCollection collection)
        {
            if (!_carros.DeletarCarro(id))
                Session["Message"] = "Erro ao abrir conexão! Verificar arquivo ReadMe.txt";
            else
                Session["Message"] = "";

            return RedirectToAction("Index");
        }

        public ViewResult EditarCarro(int id)
        {
            _carros.listCarros.Where(i => i.ID == id);
            return View(_carros.GetCarro(id));
        }

        [HttpPost]
        public ActionResult EditarCarro(int id, FormCollection collection, CarroModel _carroModel)
        {
            if (!_carros.AtualizaCarro(id, _carroModel))
                Session["Message"] = "Erro ao abrir conexão! Verificar arquivo ReadMe.txt";
            else
                Session["Message"] = "";

            return RedirectToAction("Index");
        }
    }
}

