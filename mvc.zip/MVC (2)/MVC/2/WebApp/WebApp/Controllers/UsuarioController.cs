﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApp.Models;

namespace WebApp.Controllers
{
    public class UsuarioController : Controller
    {
        private static Usuarios _usuarios = new Usuarios();

        public ActionResult Index()
        {
            Usuarios user = new Usuarios();
            return View(user.listUsuarios);
        }

        public ActionResult AdicionaUsuario()
        {
            return View();
        }

        [HttpPost]
        public ActionResult AdicionaUsuario(UsuarioModel _usuarioModel)
        {

            if (!_usuarios.CriaUsuario(_usuarioModel))
                Session["Message"] = "Erro ao abrir conexão! Verificar arquivo ReadMe.txt";
            else
                Session["Message"] = "";
            return RedirectToAction("Index");

        }

        public ViewResult DeletaUsuario(int id)
        {
            _usuarios.listUsuarios.Where(i => i.ID == id);
            return View(_usuarios.GetUsuario(id));
        }

        [HttpPost]
        public RedirectToRouteResult DeletaUsuario(int id, FormCollection collection)
        {
            if (!_usuarios.DeletarUsuario(id))
                Session["Message"] = "Erro ao abrir conexão! Verificar arquivo ReadMe.txt";
            else
                Session["Message"] = "";
            return RedirectToAction("Index");
        }

        public ViewResult EditarUsuario(int id)
        {
            _usuarios.listUsuarios.Where(i => i.ID == id);
            return View(_usuarios.GetUsuario(id));
        }

        [HttpPost]
        public ActionResult EditarUsuario(int id, FormCollection collection, UsuarioModel _usuarioModel)
        {
            if (!_usuarios.AtualizaUsuario(id, _usuarioModel))
                Session["Message"] = "Erro ao abrir conexão! Verificar arquivo ReadMe.txt";
            else
                Session["Message"] = "";

            return RedirectToAction("Index");
        }
    }

}

